/**
 * Created by kongjg on 16/8/16.
 */
// 当PhoneGap加载完毕后调用onDeviceReady回调函数
// 此时，该文件已加载完毕但phonegap.js还没有加载完毕。
// 当PhoneGap加载完毕并开始和本地设备进行通讯，
// 就会触发“deviceready”事件。
document.addEventListener('deviceready',onDeviceReady,false);
// PhoneGap加载完毕，现在可以安全地调用PhoneGap方法

function onDeviceReady(){
    var url = "http://www.baidu.com";
    window.open(url,'_self','location=no');
}

/*
function onDeviceReady(){
    Wechat.isInstalled(function (installed) {
        alert("Wechat installed: " + (installed ? "Yes" : "No"));
    }, function (reason) {
        alert("Failed: " + reason);
    });

//微信分享
//    验证
    var scope = "snsapi_userinfo",
        state = "_" + (+new Date());
    Wechat.auth(scope, state, function (response) {
        // you may use response.code to get the access token.
        alert(JSON.stringify(response));
    }, function (reason) {
        alert("Failed: " + reason);
    });

//Wechat.Scene.TIMELINE 表示分享到朋友圈
    function shareTimeLine(){
        Wechat.share({
            //message: {
            //    media: {
            //        type: Wechat.Type.LINK,
            //        webpageUrl: "http://tech.qq.com/zt2012/tmtdecode/252.htm"
            //    }
            //},
            text: "This is just a plain string",
            scene: Wechat.Scene.TIMELINE   // share to Timeline
        }, function () {
            alert("Success");
        }, function (reason) {
            alert("Failed: " + reason);
        });
    }
//Wechat.Scene.SESSION 表示分享给好友
//（1）文本
    function shareScene(){
        Wechat.share({
            text: "This is just a plain string",
            scene: Wechat.Scene.TIMELINE   // share to Timeline
        }, function () {
            alert("Success");
        }, function (reason) {
            alert("Failed: " + reason);
        });
    }

    //（2）媒体
    function shareMedia(){
        Wechat.share({
            message: {
                title: "Hi, there",
                description: "This is description.",
                thumb: "www/img/thumbnail.png",
                mediaTagName: "TEST-TAG-001",
                messageExt: "这是第三方带的测试字段",
                messageAction: "<action>dotalist</action>",
                media: "YOUR_MEDIA_OBJECT_HERE"
            },
            scene: Wechat.Scene.TIMELINE   // share to Timeline
        }, function () {
            alert("Success");
        }, function (reason) {
            alert("Failed: " + reason);
        });
    }


    //（3）网页链接
    function shareLink(){
        Wechat.share({
            message: {
                media: {
                    type: Wechat.Type.LINK,
                    webpageUrl: "http://tech.qq.com/zt2012/tmtdecode/252.htm"
                }
            },
            scene: Wechat.Scene.TIMELINE   // share to Timeline
        }, function () {
            alert("Success");
        }, function (reason) {
            alert("Failed: " + reason);
        });

    }


    document.getElementById('shareTimeLine').addEventListener('click',shareTimeLine);
    document.getElementById('shareScene').addEventListener('click',shareScene);
    document.getElementById('shareMedia').addEventListener('click',shareMedia);
    document.getElementById('shareLink').addEventListener('click',shareLink);



}

*/